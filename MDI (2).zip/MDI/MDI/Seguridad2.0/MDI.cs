﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using InicioSesion;
using BIT;
using Recetas;
using ProduccionDLL;
using CapaDiseño;
using RecursosHumanos;
using OrdenesProd;
using I_E_DLL;

namespace MDI
{
    public partial class MDI : Form
    {
        graphicLayer cpg = new graphicLayer();
        String id_usuario;
        public MDI()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MdiClient ctlMDI;
            foreach (Control ctl in this.Controls)
            {
                try
                {
                    ctlMDI = (MdiClient)ctl;
                    ctlMDI.BackColor = this.BackColor;
                }
                catch (InvalidCastException exc)
                {
                }
            }
            DateTime fecha = DateTime.Now;
            this.labelFecha.Text = String.Format("{0:MM/dd/yyyy}", DateTime.Now);
            this.labelHora.Text = String.Format("{0:HH:mm:ss}", DateTime.Now);
            timer1.Interval = 1000;
            timer1.Start();
            panel2.Location = new Point(20, this.Height - 175);
            panel3.Location = new Point(this.Width - 300, this.Height - 115);
            Btn_close.Location = new Point(this.Width - 41, 0);
            Btn_min.Location = new Point(this.Width - 82, 0);
            InicioSesionForm inicioSes = new InicioSesionForm();
            inicioSes.FormClosed += new FormClosedEventHandler(form2_FormClosed);
            inicioSes.ShowDialog();
            inicioSes.TopMost = true;
            inicioSes.Activate();
            Usuario u = new Usuario();
            id_usuario = "" + u.obtenerCodigoUsuario();
        }


        void form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Usuario u = new Usuario();
            lbl_usuario.Text = u.obtenerUsuario();
            id_usuario = "" + u.obtenerCodigoUsuario();
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.labelFecha.Text = String.Format("{0:MM/dd/yyyy}", DateTime.Now);
            this.labelHora.Text = String.Format("{0:hh:mm:ss}", DateTime.Now);
        }
        private void Form1_SizeChanged(object sender, EventArgs e)
        {
        }

        private void MDI_Paint(object sender, PaintEventArgs e)
        {
        }

        private void Btn_close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Btn_min_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void ordenesDeCompraToolStripMenuItem1_Click(object sender, EventArgs e)
        {
        }

        private void ordenesDeDevolucionToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void mantenimientoModeloToolStripMenuItem_Click(object sender, EventArgs e)
        {
            produccion_2102 nuevo = new produccion_2102(null, id_usuario, null, -1);
            nuevo.ShowDialog();
            /*Usuario user = new Usuario();
            user.guardarCodigoApp("5620");
            ModelosLogistica frm = new ModelosLogistica();
            frm.MdiParent = this;
            frm.Show();
            Application.DoEvents();
            frm.Location = new Point((this.Width - frm.Width) / 2, 0);
            */
        }

        private void mantenimientoMarcaToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void generarPolizaToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void trasladoDeProductosToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void mantemientoSedesToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void mantenimientoDestinosToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void mantenimientoRutasToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void bitacoraToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmBitacora formbitacora = new frmBitacora();
            formbitacora.MdiParent = this;
            formbitacora.Show();
            formbitacora.MdiParent = this;

            Application.DoEvents();
            formbitacora.Location = new Point((this.Width - formbitacora.Width) / 2, 0);
        }

        private void inicioToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void mantenimientosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void estadoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _2025_Estado nuevo = new _2025_Estado();
            nuevo.ShowDialog();
        }

        private void frmInicioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPrincipal nuevo = new frmPrincipal();
            nuevo.ShowDialog();
        }

        private void prioridadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _2015_Prioridad nuevo = new _2015_Prioridad();
            nuevo.ShowDialog();
        }

        private void estadoToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _2025_Estado nuevo = new _2025_Estado();
            nuevo.ShowDialog();
        }

        private void operacionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _2035_Linea nuevo = new _2035_Linea();
            nuevo.ShowDialog();
        }

        private void mantenimientosToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void consultarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            produccion_2101 nuevo = new produccion_2101(id_usuario);
            nuevo.ShowDialog();
        }

        private void gestionarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            produccion_2102 nuevo = new produccion_2102(null,id_usuario,null,-1);
            nuevo.ShowDialog();
        }

        private void integraciónRRHHToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void ingresoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ingreso nuevo = new Ingreso();
            nuevo.ShowDialog();
        }

        private void procesoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            _2603_Proceso nuevo = new _2603_Proceso();
            nuevo.ShowDialog();
        }

        private void operacionToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            _2602_Operaciones nuevo = new _2602_Operaciones();
            nuevo.ShowDialog();
        }

        private void ordenesDeProducciónToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OrdenesProduccion_2201 nuevo = new OrdenesProduccion_2201();
            nuevo.ShowDialog();
        }

        private void implosiónExplosiónDeMateriaToolStripMenuItem_Click(object sender, EventArgs e)
        {
           frm_explosion nuevo = new frm_explosion();
           nuevo.ShowDialog();
        }

        /* EJEMPLO DE APERTURA DE UN FORM 
         * 
         *  Capa_Grafica_Solicitud_de_Compra frm = new Capa_Grafica_Solicitud_de_Compra();  <---- Nombre del form
         *  frm.MdiParent = this;                                                           <---- Asignacion de mdi padre
         *  frm.Show();                                                                     <---- Mostrar el form
         *  Application.DoEvents();                                                         
         *  frm.Location = new Point((this.Width - frm.Width) / 2, 0);                      <---- Centrado del form
         *  
         */
    }
}
