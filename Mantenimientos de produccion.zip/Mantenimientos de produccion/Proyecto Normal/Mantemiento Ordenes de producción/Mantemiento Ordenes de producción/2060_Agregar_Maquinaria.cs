﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaDiseno;

namespace Mantemiento_Ordenes_de_producción
{
    public partial class _2060_Agregar_Materia : Form
    {
        Navegador nav = new Navegador();
        public _2060_Agregar_Materia()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void _2060_Agregar_Materia_Load(object sender, EventArgs e)
        {
            nav.ingresarTabla("tbl_maquinaria");
        }
    }
}
