﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Collections;
using CapaDatos;


namespace CapaLogica
{
    public class Logica
    {
        Datos dt = new Datos();

    }
}
