﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Odbc;
using System.Data;
using System.Collections;
using System.Windows



namespace CapaDatos
{
    public class Datos
    {
        static OdbcConnection cnx = null;


        public static OdbcConnection getDB()
        {
            cnx = new OdbcConnection(Properties.Settings.Default.Ruta);
            cnx.Open();
            return cnx;
        }

    }
}
