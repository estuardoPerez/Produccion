﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaDiseno;
using System.Data.Odbc;

namespace CapaDiseño
{
    public partial class _2020_Agregar_Prioridad : Form
    {
        Navegador nav = new Navegador();

        public _2020_Agregar_Prioridad()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void _2020_Agregar_Prioridad_Load(object sender, EventArgs e)
        {
            nav.ingresarTabla("tbl_prioridad");
        }
    }
}
