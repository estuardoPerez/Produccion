﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaDiseno;
namespace CapaDiseño
{
    public partial class _2040_Agregar_Linea : Form
    {
        Navegador nav = new Navegador();
        public _2040_Agregar_Linea()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void _2040_Agregar_Linea_Load(object sender, EventArgs e)
        {
            nav.ingresarTabla("tbl_operacion");
        }
    }
}
