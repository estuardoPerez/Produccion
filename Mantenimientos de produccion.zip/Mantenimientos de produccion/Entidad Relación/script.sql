﻿
-- -----------------------------------------------------
-- Table `TBL_Prioridad`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Prioridad` (
  `idTBL_Prioridad` INT NOT NULL,
  `descripcion_Prioridad` VARCHAR(45) NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Prioridad`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Operacion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Operacion` (
  `idTBL_Operacion` INT NOT NULL,
  `Nombre_operacion` VARCHAR(45) NULL,
  `Descripcion` VARCHAR(100) NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Operacion`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Estado_Avance`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Estado_Avance` (
  `idTBL_Estado_Avance` INT NOT NULL,
  `Estado_Avance` VARCHAR(45) NULL,
  `Fecha_ultimoMov` DATE NULL,
  `TBL_Operacion_idTBL_Operacion` INT NOT NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Estado_Avance`, `TBL_Operacion_idTBL_Operacion`),
  INDEX `fk_TBL_Estado_Avance_TBL_Operación1_idx` (`TBL_Operacion_idTBL_Operacion` ASC),
  CONSTRAINT `fk_TBL_Estado_Avance_TBL_Operación1`
    FOREIGN KEY (`TBL_Operacion_idTBL_Operacion`)
    REFERENCES `TBL_Operacion` (`idTBL_Operacion`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Orden_Produccion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Orden_Produccion` (
  `idTBL_Orden_Produccion` INT NOT NULL,
  `Creador_orden` VARCHAR(45) NULL,
  `Fecha_Inicio` DATE NULL,
  `Fecha_Finalizacion` DATE NULL,
  `TBL_Prioridad_idTBL_Prioridad` INT NOT NULL,
  `TBL_Estado_Avance_idTBL_Estado_Avance` INT NOT NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Orden_Produccion`, `TBL_Prioridad_idTBL_Prioridad`, `TBL_Estado_Avance_idTBL_Estado_Avance`),
  INDEX `fk_TBL_Orden_Produccion_TBL_Prioridad1_idx` (`TBL_Prioridad_idTBL_Prioridad` ASC),
  INDEX `fk_TBL_Orden_Produccion_TBL_Estado_Avance1_idx` (`TBL_Estado_Avance_idTBL_Estado_Avance` ASC),
  CONSTRAINT `fk_TBL_Orden_Produccion_TBL_Prioridad1`
    FOREIGN KEY (`TBL_Prioridad_idTBL_Prioridad`)
    REFERENCES `TBL_Prioridad` (`idTBL_Prioridad`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Orden_Produccion_TBL_Estado_Avance1`
    FOREIGN KEY (`TBL_Estado_Avance_idTBL_Estado_Avance`)
    REFERENCES `TBL_Estado_Avance` (`idTBL_Estado_Avance`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Receta`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Receta` (
  `PK_Receta` INT NOT NULL,
  `nombre_receta` VARCHAR(45) NULL,
  `creacion_receta` DATE NULL,
  `estatus` INT NULL,
  `FK_Usu_Codigo` INT NOT NULL,
  `FK_Codigo_Producto` INT NOT NULL,
  PRIMARY KEY (`PK_Receta`),
  INDEX `fk_TBL_Receta_TBL_Usuario1_idx` (`FK_Usu_Codigo` ASC),
  INDEX `fk_TBL_Receta_TBL_Producto1_idx` (`FK_Codigo_Producto` ASC),
  CONSTRAINT `fk_TBL_Receta_TBL_Usuario1`
    FOREIGN KEY (`FK_Usu_Codigo`)
    REFERENCES `TBL_Usuario` (`PK_Usu_Codigo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Receta_TBL_Producto1`
    FOREIGN KEY (`FK_Codigo_Producto`)
    REFERENCES `TBL_Producto` (`PK_Codigo_Producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Receta_Detalle`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Receta_Detalle` (
  `PK_Receta_Materia` INT NOT NULL AUTO_INCREMENT,
  `cantidad_materia` FLOAT NULL,
  `estatus` INT NULL,
  `FK_Receta` INT NOT NULL,
  `FK_Codigo_Producto` INT NOT NULL,
  `FK_CodigoDeUnidadDeMedidaBase` INT NOT NULL,
  PRIMARY KEY (`PK_Receta_Materia`),
  INDEX `fk_TBL_Receta_Materia_TBL_Receta1_idx` (`FK_Receta` ASC),
  INDEX `fk_TBL_Detalle_Receta_TBL_Producto1_idx` (`FK_Codigo_Producto` ASC),
  INDEX `fk_TBL_Receta_Detalle_TBL_UnidadDeMedidaBase1_idx` (`FK_CodigoDeUnidadDeMedidaBase` ASC),
  CONSTRAINT `fk_TBL_Receta_Materia_TBL_Receta1`
    FOREIGN KEY (`FK_Receta`)
    REFERENCES `TBL_Receta` (`PK_Receta`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Detalle_Receta_TBL_Producto1`
    FOREIGN KEY (`FK_Codigo_Producto`)
    REFERENCES `TBL_Producto` (`PK_Codigo_Producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Receta_Detalle_TBL_UnidadDeMedidaBase1`
    FOREIGN KEY (`FK_CodigoDeUnidadDeMedidaBase`)
    REFERENCES `TBL_unidaddemedidabase` (`PK_CodigoDeUnidadDeMedidaBase`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Proceso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Proceso` (
  `idTBL_Proceso` INT NOT NULL,
  `TBL_Operacion_idTBL_Operacion` INT NOT NULL,
  `Nombre_proceso` VARCHAR(45) NULL,
  `Descripcion` VARCHAR(100) NULL,
  `pk_id_receta_materia` INT NOT NULL,
  `Operarios requeridos` INT NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Proceso`),
  INDEX `fk_TBL_Proceso_TBL_Operación1_idx` (`TBL_Operacion_idTBL_Operacion` ASC),
  INDEX `fk_TBL_Proceso_TBL_Detalle_Receta1_idx` (`pk_id_receta_materia` ASC),
  CONSTRAINT `fk_TBL_Proceso_TBL_Operación1`
    FOREIGN KEY (`TBL_Operacion_idTBL_Operacion`)
    REFERENCES `TBL_Operacion` (`idTBL_Operacion`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Proceso_TBL_Detalle_Receta1`
    FOREIGN KEY (`pk_id_receta_materia`)
    REFERENCES `TBL_Receta_Detalle` (`PK_Receta_Materia`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_ConceptosCosteProduccion`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_ConceptosCosteProduccion` (
  `PK_ConceptoCosteProduccion` INT NOT NULL,
  `unidades_producidas` INT NULL,
  `costo_unitario` INT NULL,
  `costo_total` INT NULL,
  `materiales` INT NULL,
  `manoObraDirecta` INT NULL,
  `costosIndirectosDeFabricacion` INT NULL,
  `costoTotalDeProduccion` INT NULL,
  PRIMARY KEY (`PK_ConceptoCosteProduccion`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Coste_ProduccionPersonal`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Coste_ProduccionPersonal` (
  `PK_TBL_CostoPersonalProduccion` INT NOT NULL,
  `PK_ConceptoCosteProduccion` INT NULL,
  `idTBL_Empleado` INT NULL,
  PRIMARY KEY (`PK_TBL_CostoPersonalProduccion`),
  INDEX `PK_ConceptoCosteProduccion_idx` (`PK_ConceptoCosteProduccion` ASC),
  CONSTRAINT `PK_ConceptoCosteProduccion`
    FOREIGN KEY (`PK_ConceptoCosteProduccion`)
    REFERENCES `TBL_ConceptosCosteProduccion` (`PK_ConceptoCosteProduccion`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_ConceptoControlDeCalidad`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_ConceptoControlDeCalidad` (
  `PK_TBL_ConceptoControlDeCalidad` INT NOT NULL,
  `estadoConceptoControlDeCalidadcol` VARCHAR(45) NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`PK_TBL_ConceptoControlDeCalidad`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_ConceptoProduccionArea`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_ConceptoProduccionArea` (
  `PK_ProduccionArea` INT NOT NULL,
  `unidadesPorProducir` INT NULL,
  `tiempoProduccionProducto` INT NULL,
  `costoProduccionProducto` INT NULL,
  `unidadesProducidas` INT NULL,
  `fechaInicioProduccion` DATETIME NULL,
  `fechaFinalProduccion` DATETIME NULL,
  `TBL_Proceso_idTBL_Proceso` INT NOT NULL,
  `estatus` INT NULL,
  `PK_TBL_CostoPersonalProduccion` INT NULL,
  `TBL_ConceptoControlDeCalidad_PK_TBL_ConceptoControlDeCalidad` INT NOT NULL,
  PRIMARY KEY (`PK_ProduccionArea`),
  INDEX `fk_TBL_CoceptoProducciónArea_TBL_Proceso1_idx` (`TBL_Proceso_idTBL_Proceso` ASC),
  INDEX `PK_TBL_CostoPersonalProduccion_idx` (`PK_TBL_CostoPersonalProduccion` ASC),
  INDEX `fk_TBL_ConceptoProduccionArea_TBL_ConceptoControlDeCalidad1_idx` (`TBL_ConceptoControlDeCalidad_PK_TBL_ConceptoControlDeCalidad` ASC),
  CONSTRAINT `fk_TBL_CoceptoProducciónArea_TBL_Proceso1`
    FOREIGN KEY (`TBL_Proceso_idTBL_Proceso`)
    REFERENCES `TBL_Proceso` (`idTBL_Proceso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `PK_TBL_CostoPersonalProduccion`
    FOREIGN KEY (`PK_TBL_CostoPersonalProduccion`)
    REFERENCES `TBL_Coste_ProduccionPersonal` (`PK_TBL_CostoPersonalProduccion`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_ConceptoProduccionArea_TBL_ConceptoControlDeCalidad1`
    FOREIGN KEY (`TBL_ConceptoControlDeCalidad_PK_TBL_ConceptoControlDeCalidad`)
    REFERENCES `TBL_ConceptoControlDeCalidad` (`PK_TBL_ConceptoControlDeCalidad`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Horas_hombre`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Horas_hombre` (
  `TBL_CoceptoProduccionArea_PK_ProduccionArea` INT NOT NULL,
  `Sueldo_base` INT NULL,
  `Días_laborados` INT NULL,
  `Horas_basicas` INT NULL,
  `Total_horas_hombre` DOUBLE NULL,
  `Sueldo_diario` DOUBLE NULL,
  `estatus` INT NULL,
  INDEX `fk_TBL_Horas_hombre_TBL_CoceptoProducciónArea1_idx` (`TBL_CoceptoProduccionArea_PK_ProduccionArea` ASC),
  CONSTRAINT `fk_TBL_Horas_hombre_TBL_CoceptoProducciónArea1`
    FOREIGN KEY (`TBL_CoceptoProduccionArea_PK_ProduccionArea`)
    REFERENCES `TBL_ConceptoProduccionArea` (`PK_ProduccionArea`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Implosion_Materiales`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Implosion_Materiales` (
  `idTBL_Implosion_Materiales` INT NOT NULL,
  `Cantidad_Max` FLOAT NULL,
  `Costo_Estimado` FLOAT NULL,
  `pk_codigo_producto` INT NOT NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Implosion_Materiales`, `pk_codigo_producto`),
  INDEX `fk_TBL_Implosion_Materiales_TBL_Producto1_idx` (`pk_codigo_producto` ASC),
  CONSTRAINT `fk_TBL_Implosion_Materiales_TBL_Producto1`
    FOREIGN KEY (`pk_codigo_producto`)
    REFERENCES `TBL_Producto` (`PK_Codigo_Producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Explosion_Materiales`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Explosion_Materiales` (
  `idTBL_Explosion_Materiales` INT NOT NULL,
  `Cantidad_prod` FLOAT NULL,
  `Status` TINYINT(1) NULL,
  `Faltante` FLOAT NULL,
  `pk_codigo_producto` INT NOT NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Explosion_Materiales`),
  INDEX `fk_TBL_Explosion_Materiales_TBL_Producto1_idx` (`pk_codigo_producto` ASC),
  CONSTRAINT `fk_TBL_Explosion_Materiales_TBL_Producto1`
    FOREIGN KEY (`pk_codigo_producto`)
    REFERENCES `TBL_Producto` (`PK_Codigo_Producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_ConceptoProductosTerminados`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_ConceptoProductosTerminados` (
  `PK_TBL_ProductosTermiandos` INT NOT NULL,
  `PK_TBL_TipoDeProducto` INT NULL,
  `cantiadProductoTerminado` INT NULL,
  `precioProductoTerminado` INT NULL,
  `PK_CostoDeProductoIndividual` INT NULL,
  `TBL_ConceptoProducciónArea_PK_ProduccionArea` INT NOT NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`PK_TBL_ProductosTermiandos`),
  INDEX `fk_TBL_ConceptoProductosTerminados_TBL_CoceptoProducciónAr_idx` (`TBL_ConceptoProducciónArea_PK_ProduccionArea` ASC),
  CONSTRAINT `fk_TBL_ConceptoProductosTerminados_TBL_CoceptoProducciónArea1`
    FOREIGN KEY (`TBL_ConceptoProducciónArea_PK_ProduccionArea`)
    REFERENCES `TBL_ConceptoProduccionArea` (`PK_ProduccionArea`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Estado_proceso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Estado_proceso` (
  `idTBL_Estado_proceso` INT NOT NULL,
  `Nombre` VARCHAR(45) NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Estado_proceso`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Estado_empleado`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Estado_empleado` (
  `idTBL_Estado` INT NOT NULL,
  `Descripcion` VARCHAR(45) NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Estado`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Insercion_empleado_proceso`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Insercion_empleado_proceso` (
  `TBL_Empleado_idTBL_Empleado` INT NOT NULL,
  `TBL_Estado_proceso_idTBL_Estado_proceso` INT NOT NULL,
  `TBL_Estado_idTBL_Estado` INT NOT NULL,
  `TBL_Proceso_idTBL_Proceso` INT NOT NULL,
  `Fecha_inicio` DATE NULL,
  `Fecha_final_contemplada` DATE NULL,
  `estatus` INT NULL,
  INDEX `fk_TBL_Insercion_empleado_proceso_TBL_Estado_proceso1_idx` (`TBL_Estado_proceso_idTBL_Estado_proceso` ASC),
  INDEX `fk_TBL_Insercion_empleado_proceso_TBL_Estado1_idx` (`TBL_Estado_idTBL_Estado` ASC),
  INDEX `fk_TBL_Insercion_empleado_proceso_TBL_Proceso1_idx` (`TBL_Proceso_idTBL_Proceso` ASC),
  INDEX `fk_TBL_Insercion_empleado_proceso_TBL_Empleado1_idx` (`TBL_Empleado_idTBL_Empleado` ASC),
  CONSTRAINT `fk_TBL_Insercion_empleado_proceso_TBL_Estado_proceso1`
    FOREIGN KEY (`TBL_Estado_proceso_idTBL_Estado_proceso`)
    REFERENCES `TBL_Estado_proceso` (`idTBL_Estado_proceso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Insercion_empleado_proceso_TBL_Estado1`
    FOREIGN KEY (`TBL_Estado_idTBL_Estado`)
    REFERENCES `TBL_Estado_empleado` (`idTBL_Estado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Insercion_empleado_proceso_TBL_Proceso1`
    FOREIGN KEY (`TBL_Proceso_idTBL_Proceso`)
    REFERENCES `TBL_Proceso` (`idTBL_Proceso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Insercion_empleado_proceso_TBL_Empleado1`
    FOREIGN KEY (`TBL_Empleado_idTBL_Empleado`)
    REFERENCES `TBL_Empleado` (`idTBL_Empleado`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Orden_Detalle`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Orden_Detalle` (
  `idTBL_Orden_Detalle` INT NOT NULL,
  `TBL_Orden_Produccion_idTBL_Orden_Produccion` INT NOT NULL,
  `TBL_Producto_pk_codigo_producto` INT NOT NULL,
  `Cantidad_prod` FLOAT NULL,
  `TBL_Explosion_Materiales_idTBL_Explosion_Materiales` INT NOT NULL,
  `estatus` INT NULL,
  PRIMARY KEY (`idTBL_Orden_Detalle`, `TBL_Orden_Produccion_idTBL_Orden_Produccion`, `TBL_Producto_pk_codigo_producto`, `TBL_Explosion_Materiales_idTBL_Explosion_Materiales`),
  INDEX `fk_TBL_Orden_Detalle_TBL_Orden_Produccion1_idx` (`TBL_Orden_Produccion_idTBL_Orden_Produccion` ASC),
  INDEX `fk_TBL_Orden_Detalle_TBL_Producto1_idx` (`TBL_Producto_pk_codigo_producto` ASC),
  INDEX `fk_TBL_Orden_Detalle_TBL_Explosion_Materiales1_idx` (`TBL_Explosion_Materiales_idTBL_Explosion_Materiales` ASC),
  CONSTRAINT `fk_TBL_Orden_Detalle_TBL_Orden_Produccion1`
    FOREIGN KEY (`TBL_Orden_Produccion_idTBL_Orden_Produccion`)
    REFERENCES `TBL_Orden_Produccion` (`idTBL_Orden_Produccion`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Orden_Detalle_TBL_Producto1`
    FOREIGN KEY (`TBL_Producto_pk_codigo_producto`)
    REFERENCES `TBL_Producto` (`PK_Codigo_Producto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_TBL_Orden_Detalle_TBL_Explosion_Materiales1`
    FOREIGN KEY (`TBL_Explosion_Materiales_idTBL_Explosion_Materiales`)
    REFERENCES `TBL_Explosion_Materiales` (`idTBL_Explosion_Materiales`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `TBL_Maquinaria`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `TBL_Maquinaria` (
  `idTBL_Maquinaria` INT NOT NULL,
  `Nombre_maquinaria` VARCHAR(45) NULL,
  `Descripcion_maquinaria` VARCHAR(45) NULL,
  `TBL_Proceso_idTBL_Proceso` INT NOT NULL,
  PRIMARY KEY (`idTBL_Maquinaria`, `TBL_Proceso_idTBL_Proceso`),
  INDEX `fk_TBL_Maquinaria_TBL_Proceso1_idx` (`TBL_Proceso_idTBL_Proceso` ASC),
  CONSTRAINT `fk_TBL_Maquinaria_TBL_Proceso1`
    FOREIGN KEY (`TBL_Proceso_idTBL_Proceso`)
    REFERENCES `TBL_Proceso` (`idTBL_Proceso`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;
